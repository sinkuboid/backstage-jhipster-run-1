export { default as TranslateDirective } from './translate.directive';
export { default as FindLanguageFromKeyPipe } from './find-language-from-key.pipe';
